# Setup Guide

## Prerequisites

The following components are required:

- Kali Linux
- Python 3 environment
- HexStrike AI
- Claude Desktop
- HexStrike MCP integration
- SSH access when a remote Kali/Windows architecture is used

## 1. Prepare the Kali Environment

Clone or obtain the official HexStrike AI project in the Kali Linux environment.

Official project:

https://github.com/morpheusc/Hexstrike-AI

Create/use a dedicated Python virtual environment and install the project's required dependencies according to the official documentation.

## 2. Start HexStrike AI

Start the HexStrike server on the configured API port.

Example project configuration used in this integration:

```text
Host: 127.0.0.1 / 0.0.0.0
Port: 8888
Version: 6.0.0
```

The exact startup command may vary with the HexStrike release and installation method. Follow the official HexStrike documentation for the current command.

## 3. Configure MCP

Configure the HexStrike MCP client so that it can communicate with the HexStrike API.

The Claude Desktop configuration should reference the HexStrike MCP component supplied by the official project rather than an untrusted third-party implementation.

Do not commit a Claude Desktop configuration containing:

- API keys
- passwords
- private keys
- access tokens
- personal credentials

## 4. Remote Kali Architecture

When Claude Desktop and Kali Linux are running on different systems, SSH port forwarding can be used to securely connect the environments.

Conceptually:

```text
Windows / Claude Desktop
          │
          │ SSH Tunnel
          ▼
       Kali Linux
          │
          ▼
   HexStrike API :8888
```

Keep the tunnel restricted to the required local/remote endpoints.

## 5. Start the MCP Client

Start the HexStrike MCP component according to the official HexStrike documentation.

A successful connection should indicate that the MCP server is ready to serve the AI client.

## 6. Verify Claude Desktop

Open Claude Desktop and verify that the HexStrike MCP server appears as available/running in the configured MCP or developer interface.

Expected state:

```text
hexstrike-ai
Status: Running
```

## 7. Verify API Health

Verify that the HexStrike backend reports a healthy status and the expected version.

Expected validation information:

```text
Health: healthy
Version: 6.0.0
```

## 8. Troubleshooting Checklist

### MCP server does not start

Check:

- Python environment is active.
- Required dependencies are installed.
- The configured executable/script path is correct.
- The HexStrike API is reachable.

### Claude Desktop cannot connect

Check:

- MCP configuration syntax.
- MCP process path.
- HexStrike API availability.
- SSH tunnel status, if used.
- Port `8888` forwarding.
- Local firewall rules.

### API is unreachable

Check:

```text
HexStrike server status
Listening address
Port 8888
SSH tunnel
Network connectivity
```

### Command execution fails

Verify that the requested tool is installed and available in the Kali environment.

Example:

```bash
which nmap
```

Expected output in the validated environment:

```text
/usr/bin/nmap
```

## Security Recommendations

- Do not expose HexStrike's API to the public Internet unless there is a specific, properly secured requirement.
- Use isolated lab targets for demonstrations.
- Keep logs and screenshots free of secrets.
- Use dedicated test accounts and systems.
- Review every command before allowing execution against a target.
