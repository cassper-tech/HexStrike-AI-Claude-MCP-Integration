# Recommended Repository Structure

```text
HexStrike-AI-Claude-MCP-Integration/
│
├── README.md
├── LICENSE
├── .gitignore
│
├── Documentation/
│   ├── Architecture.md
│   ├── Setup.md
│   └── Validation.md
│
└── Screenshots/
    ├── 01-claude-desktop-mcp-running.png
    ├── 02-hexstrike-mcp-client-connected.png
    ├── 03-hexstrike-ai-server-running.png
    ├── 04-hexstrike-api-health.png
    └── 05-nmap-command-validation.png
```

## Screenshot Naming

Use these exact names for consistency:

1. `01-claude-desktop-mcp-running.png`
2. `02-hexstrike-mcp-client-connected.png`
3. `03-hexstrike-ai-server-running.png`
4. `04-hexstrike-api-health.png`
5. `05-nmap-command-validation.png`

If your existing screenshots contain local IP addresses, usernames, tokens, file paths, or other information you do not want public, redact those details before committing them.
