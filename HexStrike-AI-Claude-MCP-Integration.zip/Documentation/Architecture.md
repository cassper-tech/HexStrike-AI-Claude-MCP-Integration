# Architecture

## Project Architecture

The integration connects Claude Desktop to security tooling on Kali Linux through the Model Context Protocol and HexStrike AI.

```mermaid
flowchart LR
    A["Claude Desktop<br/>AI Client"] -->|"MCP"| B["HexStrike MCP Server"]
    B --> C["HexStrike AI v6.0<br/>API"]
    C --> D["Kali Linux<br/>Security Environment"]
    D --> E["Nmap"]
    D --> F["Burp Suite"]
    D --> G["Nikto"]
    D --> H["SQLMap"]
    D --> I["Other Authorized Tools"]

    J["SSH Port Forwarding"] -. "Secure Connectivity" .-> C
```

## Components

### 1. Claude Desktop

Claude Desktop acts as the AI client. It communicates with the configured HexStrike MCP server and can request supported operations exposed through MCP.

### 2. Model Context Protocol

MCP provides the communication interface between the AI client and the MCP server. In this project, it is the protocol layer connecting Claude Desktop with HexStrike.

### 3. HexStrike MCP Server

The MCP component exposes HexStrike functionality to the AI client and forwards supported requests to the HexStrike backend.

### 4. HexStrike AI API

HexStrike AI provides the orchestration layer for security tooling. The API server runs on Kali Linux and exposes the configured service endpoint.

### 5. Kali Linux

Kali Linux provides the controlled execution environment containing the cybersecurity tools used for authorized testing.

### 6. Security Tools

Tools such as Nmap, Burp Suite, Nikto, and SQLMap can be integrated into the workflow where supported and where their use is authorized.

## Network Flow

The logical communication flow is:

```text
Claude Desktop
      │
      ▼
MCP Request
      │
      ▼
HexStrike MCP Server
      │
      ▼
HexStrike API :8888
      │
      ▼
Kali Linux
      │
      ▼
Authorized Security Tool
      │
      ▼
Command / Result
      │
      ▼
Claude Desktop
```

## Security Considerations

Because the integration can provide access to powerful security tools:

- Run the environment in a controlled laboratory whenever possible.
- Restrict API exposure to trusted interfaces.
- Prefer SSH tunneling or equivalent protected connectivity over exposing the API publicly.
- Never commit secrets or authentication material.
- Apply least-privilege principles where practical.
- Keep security tools and dependencies updated.
- Test only systems for which explicit authorization exists.
